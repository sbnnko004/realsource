<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <?php if(Route::getCurrentRoute()->uri()=='admin'): ?>
        <li class="breadcrumb-item active">
            Dashboard
        </li>
    <?php else: ?>
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('admin')); ?>">Dashboard</a>
        </li>
        <?php if(Route::getCurrentRoute()->uri()=='admin/blog_posts'): ?>
            <li class="breadcrumb-item active">
                Blog posts
            </li>
        <?php elseif(Route::getCurrentRoute()->uri()=='admin/blog_posts/edit'): ?>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('admin/blog_posts')); ?>">Blog posts</a>
            </li>
            <li class="breadcrumb-item active">
                Edit Post
            </li>
        <?php elseif(Route::getCurrentRoute()->uri()=='admin/blog_posts/add'): ?>
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('admin/blog_posts')); ?>">Blog posts</a>
            </li>
            <li class="breadcrumb-item active">
                Add Post
            </li>
        <?php endif; ?>
    <?php endif; ?>
</ol>
<?php /* /home/zxtnhezr/realsource/resources/views/sections/dashboard/breadcrumb.blade.php */ ?>