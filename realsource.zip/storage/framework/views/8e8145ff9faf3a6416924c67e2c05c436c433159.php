<!-- Sidebar -->
<ul class="sidebar navbar-nav">
    <?php if(Route::getCurrentRoute()->uri()=='admin'): ?>
        <li class="nav-item active">
    <?php else: ?>
        <li class="nav-item">
    <?php endif; ?> 
            <a class="nav-link" href="<?php echo e(route('manage.admin.index')); ?>">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>
    
    <?php if(Route::getCurrentRoute()->uri()=='admin/blog_posts'): ?>
        <li class="nav-item active">
    <?php else: ?>
        <li class="nav-item">
    <?php endif; ?>
        <a class="nav-link" href="<?php echo e(route('manage.admin.blog_posts')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Blog posts</span>
        </a>
    </li>    
</ul>
<?php /* C:\xampp\htdocs\realsource\resources\views/sections/dashboard/sidebar.blade.php */ ?>