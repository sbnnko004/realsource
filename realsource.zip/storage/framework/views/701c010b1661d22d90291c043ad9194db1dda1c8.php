<?php $__env->startSection('content'); ?>
    <header>
        <?php echo $__env->make('sections.main.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <div id="main">
        <?php echo $__env->make('sections.main.other.jumbotron', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.mainpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\realsource\resources\views/pages/main/about.blade.php */ ?>