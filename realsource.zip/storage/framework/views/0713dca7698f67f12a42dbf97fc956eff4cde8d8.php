<div class="card mb-3">
    <div class="card-header">
        <i class="fas fa-table"></i>
        Add Blog Posts
    </div>
    <div class="card-body">
        <div class="form-responsive">
                <?php echo Form::open(['action' => 'BlogPostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                <div class="form-group">
                    <?php echo e(Form::label('title', 'Title')); ?>

                    <?php echo e(Form::text('title','', ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('title', 'Headline')); ?>

                    <?php echo e(Form::text('headline','', ['class' => 'form-control', 'placeholder' => 'Headline'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('body', 'Body')); ?>

                    <?php echo e(Form::textarea('body','', ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Body Text'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::file('cover_image')); ?>

                </div>
                <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php /* C:\xampp\htdocs\realsource\resources\views/sections/dashboard/add.blade.php */ ?>