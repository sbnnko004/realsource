<!-- Sticky Footer -->
<footer class="sticky-footer">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
        <span>Copyright © <?php echo e(config('app.name', 'RealSource.co.za')); ?> 2019</span>
        <br>
        <span>Nkosingiphile Sibandze</span>
        </div>
    </div>
</footer>
<?php /* C:\xampp\htdocs\realsource\resources\views/sections/dashboard/sticky_footer.blade.php */ ?>