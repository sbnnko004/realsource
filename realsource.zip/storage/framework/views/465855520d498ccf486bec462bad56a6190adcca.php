

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('sections.dashboard.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="wrapper">
        <?php echo $__env->make('sections.dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="content-wrapper">
            <div class="container-fluid">
                <?php echo $__env->yieldContent('main'); ?>
            </div>
            <?php echo $__env->make('sections.dashboard.sticky_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /home/zxtnhezr/realsource/resources/views/pages/dashboard/index.blade.php */ ?>