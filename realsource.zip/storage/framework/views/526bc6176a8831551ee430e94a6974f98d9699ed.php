    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg fixed-top" id="mainNav">
      <div class="container">
          <a class="navbar-brand" href=""><img id="logo" height="42" width="auto" src="<?php echo e(asset('assets/img/logo.png')); ?>"></a>
          <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
              <i class="fa fa-bars"></i>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
              <ul class="navbar-nav ml-auto">
                <?php if(Route::currentRouteName()=='home'): ?>
                  <li class="nav-item active">
                <?php else: ?>
                    <li class="nav-item">
                <?php endif; ?>
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
                  </li>
                <?php if(Route::currentRouteName()=='about-us'): ?>
                  <li class="nav-item active">
                <?php else: ?>
                    <li class="nav-item">
                <?php endif; ?>
                    <a class="nav-link" href="<?php echo e(route('about-us')); ?>">About Us</a>
                  </li>
                <?php if(Route::currentRouteName()=='how-it-works'): ?>
                  <li class="nav-item active">
                <?php else: ?>
                    <li class="nav-item">
                <?php endif; ?>
                      <a class="nav-link" href="#">How It Works</a>
                  </li>
                <?php if(Route::currentRouteName()=='order-now'): ?>
                  <li class="nav-item active">
                <?php else: ?>
                    <li class="nav-item">
                <?php endif; ?>
                      <a class="nav-link" href="<?php echo e(route('order-now', ['step' => '1'])); ?>">Order Now</a>
                  </li>
                <!--<?php if(Route::currentRouteName()=='work-with-us'): ?>
                  <li class="nav-item active">
                <?php else: ?>
                    <li class="nav-item">
                <?php endif; ?>
                      <a class="nav-link" href="#">Work With Us</a>
                  </li>
                -->
                <?php if(Route::currentRouteName()=='freelance'): ?>
                  <li class="nav-item active">
                <?php else: ?>
                    <li class="nav-item">
                <?php endif; ?>
                      <a class="nav-link" href="#">Freelance</a>
                  </li>
                  <!--li class="nav-item">
                      <a class="nav-link" href="#">Testimonials</a>
                  </li-->
                <?php if(Route::currentRouteName()=='blog'): ?>
                  <li class="nav-item active">
                <?php else: ?>
                    <li class="nav-item">
                <?php endif; ?>
                      <a class="nav-link" href="blog">Blog</a>
                  </li>
              </ul>
              <!--ul class="navbar-nav ml-auto social-nav">
                  <li class="nav-item">
                      <a class="nav-link" href="#">
                          <img src="<?php echo e(asset('assets/img/iconfinder_facebook_313103.png')); ?>">
                      </a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="#">
                          <img src="<?php echo e(asset('assets/img/iconfinder_twitter_313075.png')); ?>">
                      </a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link" href="#">
                          <img src="<?php echo e(asset('assets/img/iconfinder_whatsapp_287520.png')); ?>">
                      </a>
                  </li>
              </ul-->
          </div>
      </div>
  </nav>
<?php /* C:\xampp\htdocs\realsource\resources\views/sections/main/nav.blade.php */ ?>