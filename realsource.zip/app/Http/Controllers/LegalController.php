<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Input;
class LegalController extends Controller
{

    

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        //$step = Input::get('step');
       // return view('pages.main.ordering')->with("step", $step);
       return;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function terms()
    {
        //
        //$step = Input::get('step');
       // return view('pages.main.ordering')->with("step", $step);
       return;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function privacy()
    {
        //
        //$step = Input::get('step');
       // return view('pages.main.ordering')->with("step", $step);
       return;
    }


}
