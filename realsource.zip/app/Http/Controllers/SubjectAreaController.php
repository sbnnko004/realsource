<?php

namespace App\Http\Controllers;

use App\SubjectArea;
use Illuminate\Http\Request;

class SubjectAreaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\SubjectArea  $subjectArea
     * @return \Illuminate\Http\Response
     */
    public function show(SubjectArea $subjectArea)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\SubjectArea  $subjectArea
     * @return \Illuminate\Http\Response
     */
    public function edit(SubjectArea $subjectArea)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\SubjectArea  $subjectArea
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SubjectArea $subjectArea)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\SubjectArea  $subjectArea
     * @return \Illuminate\Http\Response
     */
    public function destroy(SubjectArea $subjectArea)
    {
        //
    }
}
