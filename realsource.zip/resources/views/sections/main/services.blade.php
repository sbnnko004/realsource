<!-- Start Service Section -->
<section id="services">
    <div class="container-wrap">
        <div class="container">
            <h2 class="title">Services</h2>
            <div class="service-list">
                <!--container for service cards-->
                <div class="service-item">
                    <!-- service card -->
                    <div class="service-body">
                        <img src="{{ asset('assets/img/iconfinder_Build_1562682.png')}}">
                        <div class="service-body-text">
                            <!-- body -->
                            <h4> Service <!-- title --> </h4>
                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet, ex vitae.
                                <!-- Description -->
                            </p>
                            <a href="">See More<!-- See More --></a>
                        </div>
                    </div>
                    <hr>
                    <!-- Horizontal Line -->
                </div>
                <!-- end service card -->
                <div class="service-item">
                    <!-- service card -->
                    <div class="service-body">
                        <img src="{{ asset('assets/img/iconfinder_Build_1562682.png')}}">
                        <div class="service-body-text">
                            <!-- body -->
                            <h4> Service <!-- title --> </h4>
                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet, ex vitae.
                                <!-- Description -->
                            </p>
                            <a href="">See More<!-- See More --></a>
                        </div>
                    </div>
                    <hr>
                    <!-- Horizontal Line -->
                </div>
                <!-- end service card -->
                <div class="service-item">
                    <!-- service card -->
                    <div class="service-body">
                        <img src="{{ asset('assets/img/logo.jpg')}}">
                        <div class="service-body-text">
                            <!-- body -->
                            <h4> Service <!-- title --> </h4>
                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet, ex vitae.
                                <!-- Description -->
                            </p>
                            <a href="">See More<!-- See More --></a>
                        </div>
                    </div>
                    <hr>
                    <!-- Horizontal Line -->
                </div>
                <!-- end service card -->
                <div class="service-item">
                    <!-- service card -->
                    <div class="service-body">
                        <img src="{{ asset('assets/img/iconfinder_Build_1562682.png')}}">
                        <div class="service-body-text">
                            <!-- body -->
                            <h4> Service <!-- title --> </h4>
                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet, ex vitae.
                                <!-- Description -->
                            </p>
                            <a href="">See More<!-- See More --></a>
                        </div>
                    </div>
                    <hr>
                    <!-- Horizontal Line -->
                </div>
                <!-- end service card -->
                <div class="service-item">
                    <!-- service card -->
                    <div class="service-body">
                        <img src="{{ asset('assets/img/iconfinder_Build_1562682.png')}}">
                        <div class="service-body-text">
                            <!-- body -->
                            <h4> Service <!-- title --> </h4>
                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet, ex vitae.
                                <!-- Description -->
                            </p>
                            <a href="">See More<!-- See More --></a>
                        </div>
                    </div>
                    <hr>
                    <!-- Horizontal Line -->
                </div>
                <!-- end service card -->
                <div class="service-item">
                    <!-- service card -->
                    <div class="service-body">
                        <img src="{{ asset('assets/img/iconfinder_Build_1562682.png')}}">
                        <div class="service-body-text">
                            <!-- body -->
                            <h4> Service <!-- title --> </h4>
                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet, ex vitae.
                                <!-- Description -->
                            </p>
                            <a href="">See More<!-- See More --></a>
                        </div>
                    </div>
                    <hr>
                    <!-- Horizontal Line -->
                </div>
                <!-- end service card -->
                <div class="service-item">
                    <!-- service card -->
                    <div class="service-body">
                        <img src="{{ asset('assets/img/iconfinder_Build_1562682.png')}}">
                        <div class="service-body-text">
                            <!-- body -->
                            <h4> Service <!-- title --> </h4>
                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet, ex vitae.
                                <!-- Description -->
                            </p>
                            <a href="">See More<!-- See More --></a>
                        </div>
                    </div>
                    <hr>
                    <!-- Horizontal Line -->
                </div>
                <!-- end service card -->
                <div class="service-item">
                    <!-- service card -->
                    <div class="service-body">
                        <img src="{{ asset('assets/img/iconfinder_Build_1562682.png')}}">
                        <div class="service-body-text">
                            <!-- body -->
                            <h4> Service <!-- title --> </h4>
                            <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed imperdiet, ex vitae.
                                <!-- Description -->
                            </p>
                            <a href="">See More<!-- See More --></a>
                        </div>
                    </div>
                    <hr>
                    <!-- Horizontal Line -->
                </div>
                <!-- end service card -->
            </div>
            <!-- end container for service cards -->
        </div>
    </div>
</section>
<!-- End Service Section -->