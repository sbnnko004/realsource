<!-- Sticky Footer -->
<footer class="sticky-footer">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
        <span>Copyright © {{ config('app.name', 'RealSource.co.za') }} 2019</span>
        <br>
        <span>Nkosingiphile Sibandze</span>
        </div>
    </div>
</footer>