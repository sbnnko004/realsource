@extends('layouts.mainpage')

@section('content')
    <header>
        @include('sections.main.ordering.nav')
    </header>
    <div class="container" id="ordering">
        <section>
            <div id="main-grid">
                <div class="main-bar  wow slideInLeft">
                    

                    <div class="progress_bar">
                        <ul class="steps">
                            @if($step==1)
                            <li class="current" step="1">
                            @else
                            <li class="complete" step="1">
                            @endif
                                <a>
                                    <span class="step-indicator">
                                        <span></span>
                                    </span>
                                    <span class="step-title">1. Project Details</span>
                                </a>
                            </li>
                            @if($step<2)
                            <li class="" step="2">
                            @elseif($step==2)
                            <li class="current" step="2">
                            @else
                            <li class="complete" step="2">
                            @endif
                                <a>
                                    <span class="step-indicator">
                                        <span></span>
                                    </span>
                                    <span class="step-title">2. Instructions</span>
                                </a>
                            </li>
                            
                            @if($step<3)
                            <li class="" step="3">
                            @elseif($step==3)
                            <li class="current" step="3">
                            @else
                            <li class="complete" step="3">
                            @endif
                            
                                <a>
                                    <span class="step-indicator">
                                        <span></span>
                                    </span>
                                    <span class="step-title">3. Summary &amp; Review</span>
                                </a>
                            </li>
                            <li class="" step="4">
                                <a>
                                    <span class="step-indicator">
                                        <span></span>
                                    </span>
                                    <span class="step-title">4. Checkout</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="form-container">
                        @if($step==3)
                        <form id="step-form" action="https://{{$payfast->getHost()}}/eng/process" method="post">
                        @else
                        <form id="step-form">
                        @endif
                            @if($step==3)
                            <div class="form_grid fix-stage-3">
                            @else    
                            <div class="form_grid">
                            @endif
                                <div class="form_left" >
                                    @if($step==1)

                                        <div class="type-title"> Project purpose</div>
                                        <div class="project-select" data-toggle="buttons">
                                            <label class="btn btn-default active">
                                                <input name="project_purpose" checked="checked" type="radio" value="1" onchange="update('1');">
                                                <span>School</span>
                                            </label>
                                            <label class="btn btn-default ">
                                                <input name="project_purpose" type="radio" value="2" onchange="update('2');">
                                                <span>Work</span>
                                            </label>
                                        </div>
                                        <div class="type-title"> Type of service</div>
                                        <div class="service-select" data-toggle="buttons">
                                            <label class="btn btn-default active">
                                                <input name="type_of_writing" checked="checked" type="radio" value="1">
                                                <span>Writing</span>
                                            </label>
                                            <label class="btn btn-default ">
                                                <input name="type_of_writing" type="radio" value="2">
                                                <span>Editing</span>
                                            </label>
                                            <label class="btn btn-default ">
                                                <input name="type_of_writing" type="radio" value="3">
                                                <span>Proofreading</span>
                                            </label>
                                        </div>
                                        <div class="type-title">Writing level</div>
                                        <div class="level-selector">
                                            <select name="writing_level" class="custom-select level-select" required>
                                                <option></option>
                                                <option value="1">High School</option>
                                                <option value="2">1st Year</option>
                                                <option value="3">2nd Year</option>
                                                <option value="4">3rd Year</option>
                                                <option value="5">4th/Honors Year</option>
                                                <option value="6">Masters</option>
                                                <option value="7">PhD</option>
                                            </select>
                                        </div>    
                                    @elseif($step==2)
                                        <div class="type-title">Project deadline</div>
                                        <div class="dead-line-picker">
                                            <div>
                                                <input class="form-control " type="text" id="datepicker" name="deadline_date" placeholder="dd-mm-yyyy" required>
                                            </div>
                                            <div>                                            
                                                <input class="form-control" type="text" id="timepicker" name="deadline_time" placeholder="hh:mm p" required>
                                            </div>
                                        </div>
                                        <div class="type-title">Subject area</div>
                                            <select name="subject_area" class="custom-select level-select" required>
                                                <option></option>
                                                <option value="1">Option</option>
                                            </select>
                                        <div class="type-title">Subject</div>
                                        <select name="subject" class="custom-select level-select" class="form-control" required>
                                            <option value="">Please select subject</option>
                                            <option value="1">Option</option>
                                        </select>
                                        <div class="sourcing">
                                            <div class="type-title">Formating &amp; citation style</div>
                                            <div class="type-title">Number of sources</div>
                                            <select name="formating" class="custom-select level-select" required>
                                                <option value="1">None</option>
                                                <option value="2">MLA</option>
                                                <option value="3">APA</option>
                                                <option value="4">Chicago</option>
                                                <option value="5">Harvard</option>
                                                <option value="6">Cancouver</option>
                                            </select>
                                            <input id="page-count" type="number"  name="number_of_sources" value="1" min="1" step="1" required>
                                        </div>

                                    @elseif($step==3)
                                        <div class="order-info">Order #17</div>
                                        <div class="type-title order_title">Project Details:</div>
                                        <div class="common-table"> 
                                            <div class="table-name">Type of service:</div>
                                            <div class="table-value">Proofreading</div>       
                                            <div class="table-name">Project purpose:</div>
                                            <div class="table-value">School</div>
                                            <div class="table-name">Project type:</div>
                                            <div class="table-value">Interview</div>
                                            <div class="table-name">Line spacing:</div>
                                            <div class="table-value">Double</div>
                                        </div>
                                        <div class="type-title order_title">Specifications & Deadline:</div>
                                        <div class="common-table"> 
                                            <div class="table-name">Page count:</div>
                                            <div class="table-value">1</div>
                                            <div class="table-name">Formatting & citation style:</div>
                                            <div class="table-value">Harvard</div>
                                            <div class="table-name">Project deadline:</div>
                                            <div class="table-value">2019-04-26 10:00:00 GMT +3</div>
                                            <div class="table-name">Files uploaded:</div>
                                            <div class="table-value">Yes</div>
                                            <div class="table-name">Number of files uploaded:</div>
                                            <div class="table-value">3</div>
                                            <div class="table-name">Price per page:</div>
                                            <div class="table-value">R59.32</div>
                                        </div>
                                    @endif
                                
                                </div>
                                <div class="form_right" >
                                    @if($step==1)
                                        <div class="type-title">Project type</div>
                                        <div class="level-selector">
                                            <select name="project_type" class="custom-select level-select" required>
                                                <option></option>
                                                <option value="1">Admission Essay</option>
                                            </select>
                                        </div>
                                        <div class="page-setting">
                                            <div>
                                                <div class="type-title">Page Count</div>
                                                <input id="page-count" type="number"  name="page_count" value="1" min="1" step="1">
                                                <p class="word-count-results">1,200 words</p>
                                            </div>
                                            <div>
                                                <div class="type-title">Line Spacing</div>
                                                <div class="linespacing-select" data-toggle="buttons">
                                                    <label class="btn btn-default active">
                                                        <input name="line_spacing" checked="checked" type="radio" value="1">
                                                        <span>2</span>
                                                    </label>
                                                    <label class="btn btn-default ">
                                                        <input name="line_spacing" type="radio" value="2">
                                                        <span>1</span>
                                                    </label>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <!--div class="type-title">Type of referencing</div>
                                        <div class="referencing-select" data-toggle="buttons">
                                            <label class="btn btn-default active">
                                                <input name="referencing" checked="checked" type="radio" value="1">
                                                <span>MLA</span>
                                            </label>
                                            <label class="btn btn-default ">
                                                <input name="referencing" type="radio" value="2">
                                                <span>APA</span>
                                            </label>
                                            <label class="btn btn-default ">
                                                <input name="referencing" type="radio" value="3">
                                                <span>Chicago</span>
                                            </label>
                                            <label class="btn btn-default ">
                                                <input name="referencing" type="radio" value="4">
                                                <span>Harvard</span>
                                            </label>
                                            <label class="btn btn-default ">
                                                <input name="referencing" type="radio" value="5">
                                                <span>Cancouver</span>
                                            </label>
                                        </div-->
                                        <div class="type-title">Writer Preference</div>
                                        <div class="writer-select" data-toggle="buttons">
                                            <label class="btn btn-default active">
                                                <input name="writer_preference" checked="checked" type="radio" value="1">
                                                <span>Best Available</span>
                                            </label>
                                            <label  class="btn btn-default ">
                                                <input id="by-order-id" name="writer_preference" type="radio" value="2">
                                                <span>By Order ID</span>
                                            </label>
                                        </div>
                                        <input class="form-control" type="text" id="writer_by_order_id" name="writer_by_order_id" placeholder="Order ID">
                                    @elseif($step==2)
                                        <div class="type-title">Project title</div>
                                        <input class="form-control"  name="project_title" type="text" minlength="5" required>
                                        <div class="type-title">Detailed project specifications</div>
                                        <textarea class="form-control" name="project_specs" rows="5" minlength="10" required></textarea>
                                        <div class="form-check">
                                            <input type="checkbox" name="upload_later" class="form-check-input" id="upload-later" checked="false">
                                            <label class="form-check-label" for="upload-later">Upload files later</label>
                                        </div>
                                        <!-- Fine Uploader DOM Element
                                        ====================================================================== -->
                                        <div id="fine-uploader-manual-trigger"></div>
                                        <div id="file-validate" class="bg-danger"></div>
                                        <!-- Fine Uploader -->
                                        <script type="text/template" id="qq-template-manual-trigger">
                                            <div class="qq-uploader-selector qq-uploader" qq-drop-area-text="Drop files here">
                                                <div class="qq-total-progress-bar-container-selector qq-total-progress-bar-container">
                                                    <div role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" class="qq-total-progress-bar-selector qq-progress-bar qq-total-progress-bar"></div>
                                                </div>
                                                <div class="qq-upload-drop-area-selector qq-upload-drop-area" qq-hide-dropzone>
                                                    <span class="qq-upload-drop-area-text-selector"></span>
                                                </div>
                                                <div class="buttons">
                                                    <div class="qq-upload-button-selector qq-upload-button">
                                                        <div>Select files</div>
                                                    </div>
                                                </div>
                                                <span class="qq-drop-processing-selector qq-drop-processing">
                                                    <span>Processing dropped files...</span>
                                                    <span class="qq-drop-processing-spinner-selector qq-drop-processing-spinner"></span>
                                                </span>
                                                <ul class="qq-upload-list-selector qq-upload-list" aria-live="polite" aria-relevant="additions removals">
                                                    <li>
                                                        <div class="qq-progress-bar-container-selector">
                                                            <div role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" class="qq-progress-bar-selector qq-progress-bar"></div>
                                                        </div>
                                                        <span class="qq-upload-spinner-selector qq-upload-spinner"></span>
                                                        <img class="qq-thumbnail-selector" qq-max-size="100" qq-server-scale>
                                                        <span class="qq-upload-file-selector qq-upload-file"></span>
                                                        <span class="qq-edit-filename-icon-selector qq-edit-filename-icon" aria-label="Edit filename"></span>
                                                        <input class="qq-edit-filename-selector qq-edit-filename" tabindex="0" type="text">
                                                        <span class="qq-upload-size-selector qq-upload-size"></span>
                                                        <button type="button" class="qq-btn qq-upload-cancel-selector qq-upload-cancel">Cancel</button>
                                                        <button type="button" class="qq-btn qq-upload-retry-selector qq-upload-retry">Retry</button>
                                                        <button type="button" class="qq-btn qq-upload-delete-selector qq-upload-delete">Delete</button>
                                                        <span role="status" class="qq-upload-status-text-selector qq-upload-status-text"></span>
                                                    </li>
                                                </ul>
                                    
                                                <dialog class="qq-alert-dialog-selector">
                                                    <div class="qq-dialog-message-selector"></div>
                                                    <div class="qq-dialog-buttons">
                                                        <button type="button" class="qq-cancel-button-selector">Close</button>
                                                    </div>
                                                </dialog>
                                    
                                                <dialog class="qq-confirm-dialog-selector">
                                                    <div class="qq-dialog-message-selector"></div>
                                                    <div class="qq-dialog-buttons">
                                                        <button type="button" class="qq-cancel-button-selector">No</button>
                                                        <button type="button" class="qq-ok-button-selector">Yes</button>
                                                    </div>
                                                </dialog>
                                    
                                                <dialog class="qq-prompt-dialog-selector">
                                                    <div class="qq-dialog-message-selector"></div>
                                                    <input type="text">
                                                    <div class="qq-dialog-buttons">
                                                        <button type="button" class="qq-cancel-button-selector">Cancel</button>
                                                        <button type="button" class="qq-ok-button-selector">Ok</button>
                                                    </div>
                                                </dialog>
                                            </div>
                                        </script>
                                        
                                        <!--TODO: Upload File -->
                                    @elseif($step==3)
                                    <div class="summary">
                                        <div class="type-title">Summary</div>
            
                                            <div class="summary-item">
                                                <div class="summary-title">Order total:</div>
                                                <div id="total">R59.32</div>
                                            </div>
                                            <div class="summary-item">
                                                <div class="summary-title">VAT:</div>
                                                <div id="vat">R0</div>
                                            </div>
                                            
                                            <div style="display:none" id="loyalty_disc">
                                                <div class="summary-item">
                                                    <div class="summary-title">Loyalty discount (0%):</div>
                                                    <span>-R59.32</span>
                                                </div>
                                            </div>
                                            <!--
                                            <div style="display:none" id="coupon_disc">
                                                <div class="summary-item">
                                                    <div class="summary-title">Discount (<span id="disc"> </span>%):</div>
                                                    <span id="disc-usd"></span>
                                                </div>
                                            </div>
            
                                            <div class="coupon-block">
                                                <div class="coupon-wrap">
                                             
            
                                                       <a href="#" class="input-first" onclick="event.preventDefault();$('#coupon_input').show();$(this).hide()">
                                                        Have a promo code?
                                                        <span class="coupon-tooltip_wrap">
                                                            <span class="tooltip-message">
                                                                <span>Please note: Discount don`t stack.</span>
                                                            </span>
                                                        </span>
                                                    </a>
                                                    <div class="input-wrapper" style="display:none" id="coupon_input">
                                                        <div class="input-group">
                                                            <input type="text" class="form-control" name="coupon" id="coupon" placeholder="XXXXXXXX">
                                                            <span class="input-group-btn">
                                                            <button id="applycoupon" class="btn btn-primary" type="button" onclick="check_coupon();">
                                                                Apply Code
                                                            </button>
                                                        </span>
                                                        </div>
                                                    </div>
                                                    <div class="code-applied code-bigger" style="display:none;" id="cerror">
                                                        <div class="summary-item">
                                                            <div class="code-title">
                                                                <span id="code_msg"></span>
                                                                <a href="#" class="link" onclick="$('#coupon_input').show();$('#cerror').hide();">Use
                                                                    another code</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="code-applied" style="display:none;" id="code_applied">
                                                        <div class="summary-item">
                                                            <div class="code-title">
                                                                <span>Code applied</span>
                                                                <a href="#" class="link" onclick="$('#coupon_input').show();$('#code_applied').hide();">Use
                                                                    another code</a>
                                                            </div>
                                                            <div id="disc_off" class="discount">15% Off</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            
                                            </div>
                                            -->
                                        
                                            <div class="summary-item final-price">
                                                <div class="summary-title">Final price:</div>
                                                <div id="final-price">R59.32</div>
                                            </div>
                                        </div>
                                    @endif
                                    
                                </div>
                                
                            </div>
                            <div class="button-panel">
                                    
                                    @if($step==1)
                                        <div class="clearfix"></div>
                                        <div class="next-step">
                                            <button class="btn-step" id="submit_first" type="button">
                                                Go to Instructions
                                                <i class="i"></i>
                                                <span class="loading badge"><i class="fa fa-spinner fa-spin"></i></span>
                                            </button>
                                        </div>
                                    @elseif($step==2)
                                        <div class="back-step">
                                            <button class="btn-step back" id="submit_second" type="button">
                                                <i class="i"></i>
                                                <span class="loading badge"><i class="fa fa-spinner fa-spin"></i></span>
                                                Back to Project Details
                                            </button>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div class="next-step">
                                            <button class="btn-step" id="submit_second" type="button">
                                                Go to Summary &amp; Review
                                                <i class="i"></i>
                                                <span class="loading badge"><i class="fa fa-spinner fa-spin"></i></span>
                                            </button>
                                        </div>
                                    @elseif($step==3)
     {!!
                                            $payfast->paymentForm(false)
                                        !!}
                                   <div class="back-step">
                                            <button class="btn btn-step back" id="submit_second" type="button">
                                                <i class="i"></i>
                                                <span class="loading badge"><i class="fa fa-spinner fa-spin"></i></span>
                                                Back to Instructions
                                            </button>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div class="next-step">
                                            <button class="btn btn-step checkout" id="submit_third" type="button">
                                                Checkout
                                                <i class="i"></i>
                                                <span class="loading badge"><i class="fa fa-spinner fa-spin"></i></span>
                                            </button>
                                        </div>
                                    
                                    @endif
                                </div>

                            </form>
                    </div>
                    
                </div>
                <div class="side-bar wow slideInRight">
                    <img src="{{ asset('assets/img/secure-payments.png') }}" class="img">
                    <img src="{{ asset('assets/img/PayFast.png') }}" class="img">
                </div>
            </div>
        </section>
    </div>
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-12">

                    <p>Copyright  2019 - realsource.co.za. All rights reserved.</p>
                    <p>&copy; <a href="">Nkosingiphile Sibandze</a></p>
    
                </div>
            </div>
        </div>
    </footer>
    
@endsection  