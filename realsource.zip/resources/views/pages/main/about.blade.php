@extends('layouts.mainpage')

@section('content')
    <header>
        @include('sections.main.nav')
    </header>
    <div id="main">
        @include('sections.main.other.jumbotron')

    </div>
@endsection  