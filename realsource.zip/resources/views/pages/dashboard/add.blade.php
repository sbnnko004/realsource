@extends('pages.dashboard.index')

@section('main')
    @include('sections.dashboard.breadcrumb')
    @include('sections.dashboard.add')
@endsection