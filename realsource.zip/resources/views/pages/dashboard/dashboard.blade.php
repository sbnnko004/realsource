@extends('pages.dashboard.index')

@section('main')
    @include('sections.dashboard.breadcrumb')
@endsection